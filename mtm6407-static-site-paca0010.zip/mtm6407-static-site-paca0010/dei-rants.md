---
layout: Content-category

hero:
    name: "Dei Rants"
    text: "Unfiltered opinions on life’s absurdities, societal BS, or petty annoyances."
    tagline: "No filter, no nonsense – just my thoughts, loud and unapologetic."

features:
  - title: Episode 3
    thumbnail: https://img.youtube.com/vi/Omlvg3mR0K8/0.jpg
    details: we take on the rise of self-checkouts—are they actually saving us time or just another way to avoid human interaction?
    link: /DR/ep3
  - title: Episode 2
    thumbnail: https://img.youtube.com/vi/uX7MmN2NlXY/0.jpg
    details: One email feature that has caused more chaos than anything else.
    link: /DR/ep2
  - title: Episode 1
    thumbnail: https://img.youtube.com/vi/X0n8MP0PVSU/0.jpg
    details: Does the early bird really get the worm, or is sleeping in secretly better for success?
    link: /DR/ep1
---
