import { defineConfig } from 'vitepress'

// https://vitepress.dev/reference/site-config
export default defineConfig({
  title: "Dei Knows What",
  description: "-thoughts, rants, and revelations.",

  
})
